package com.android.attendance.bean;

public class AttenderBean {
	
	private int attender_id;
	private String attender_firstname;
	private String attender_lastname;
	private String attender_mobilenumber;
	private String attender_address;
	private String attender_username;
	private String attender_password;

	public int getAttender_id() {
		return attender_id;
	}

	public void setAttender_id(int attender_id) {
		this.attender_id = attender_id;
	}

	public String getAttender_firstname() {
		return attender_firstname;
	}

	public void setAttender_firstname(String attender_firstname) {
		this.attender_firstname = attender_firstname;
	}

	public String getAttender_lastname() {
		return attender_lastname;
	}

	public void setAttender_lastname(String attender_lastname) {
		this.attender_lastname = attender_lastname;
	}

	public String getAttender_mobilenumber() {
		return attender_mobilenumber;
	}

	public void setAttender_mobilenumber(String attender_mobilenumber) {
		this.attender_mobilenumber = attender_mobilenumber;
	}

	public String getAttender_address() {
		return attender_address;
	}

	public void setAttender_address(String attender_address) {
		this.attender_address = attender_address;
	}

	public String getAttender_username() {
		return attender_username;
	}

	public void setAttender_username(String attender_username) {
		this.attender_username = attender_username;
	}

	public String getAttender_password() {
		return attender_password;
	}

	public void setAttender_password(String attender_password) {
		this.attender_password = attender_password;
	}
}
