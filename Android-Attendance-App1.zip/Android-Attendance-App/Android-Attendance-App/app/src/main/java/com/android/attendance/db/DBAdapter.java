package com.android.attendance.db;

import java.util.ArrayList;

import com.android.attendance.bean.AttendanceBean;
import com.android.attendance.bean.AttendanceSessionBean;
import com.android.attendance.bean.AttenderBean;
import com.android.attendance.bean.EmployeeBean;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBAdapter extends SQLiteOpenHelper {

	// All Static variables
	// Database Version
	private static final int DATABASE_VERSION = 1;

	// Database Name
	private static final String DATABASE_NAME = "Attendance";

	// Contacts table name
	private static final String ATTENDER_INFO_TABLE = "attender_table";
	private static final String EMPLOYEE_INFO_TABLE = "employee_table";
	private static final String ATTENDANCE_SESSION_TABLE = "attendance_session_table";
	private static final String ATTENDANCE_TABLE = "attendance_table";


	// Contacts Table Columns names
	private static final String KEY_ATTENDER_ID = "attender_id";
	private static final String KEY_ATTENDER_FIRSTNAME = "attender_firstname";
	private static final String KEY_ATTENDER_LASTNAME = "attender_Lastname";
	private static final String KEY_ATTENDER_MO_NO = "attender_mobilenumber";
	private static final String KEY_ATTENDER_ADDRESS = "attender_address";
	private static final String KEY_ATTENDER_USERNAME = "attender_username";
	private static final String KEY_ATTENDER_PASSWORD = "attender_password";

	private static final String KEY_EMPLOYEE_ID = "employee_id";
	private static final String KEY_EMPLOYEE_FIRSTNAME = "employee_firstname";
	private static final String KEY_EMPLOYEE_LASTNAME = "employee_lastname";
	private static final String KEY_EMPLOYEE_MO_NO = "employee_mobilenumber";
	private static final String KEY_EMPLOYEE_ADDRESS = "employee_address";
	private static final String KEY_EMPLOYEE_DEPARTMENT = "employee_department";
	private static final String KEY_EMPLOYEE_CLASS = "employee_class";

	private static final String KEY_ATTENDANCE_SESSION_ID = "attendance_session_id";
	private static final String KEY_ATTENDANCE_SESSION_FACULTY_ID = "attendance_session_faculty_id";
	private static final String KEY_ATTENDANCE_SESSION_DEPARTMENT = "attendance_session_department";
	private static final String KEY_ATTENDANCE_SESSION_CLASS = "attendance_session_class";
	private static final String KEY_ATTENDANCE_SESSION_DATE = "attendance_session_date";
	private static final String KEY_ATTENDANCE_SESSION_SUBJECT = "attendance_session_subject";

	private static final String KEY_SESSION_ID = "attendance_session_id";
	private static final String KEY_ATTENDANCE_STUDENT_ID = "attendance_student_id";
	private static final String KEY_ATTENDANCE_STATUS = "attendance_status";


	public DBAdapter(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}


	@Override

	public void onCreate(SQLiteDatabase db) {
		String queryFaculty="CREATE TABLE "+ ATTENDER_INFO_TABLE +" (" +
				KEY_ATTENDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
				KEY_ATTENDER_FIRSTNAME + " TEXT, " +
				KEY_ATTENDER_LASTNAME + " TEXT, " +
				KEY_ATTENDER_MO_NO + " TEXT, " +
				KEY_ATTENDER_ADDRESS + " TEXT," +
				KEY_ATTENDER_USERNAME + " TEXT," +
				KEY_ATTENDER_PASSWORD + " TEXT " + ")";
		Log.d("queryFaculty",queryFaculty);


		String queryStudent="CREATE TABLE "+ EMPLOYEE_INFO_TABLE +" (" +
				KEY_EMPLOYEE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
				KEY_EMPLOYEE_FIRSTNAME + " TEXT, " +
				KEY_EMPLOYEE_LASTNAME + " TEXT, " +
				KEY_EMPLOYEE_MO_NO + " TEXT, " +
				KEY_EMPLOYEE_ADDRESS + " TEXT," +
				KEY_EMPLOYEE_DEPARTMENT + " TEXT," +
				KEY_EMPLOYEE_CLASS + " TEXT " + ")";
		Log.d("queryStudent",queryStudent );


		String queryAttendanceSession="CREATE TABLE "+ ATTENDANCE_SESSION_TABLE +" (" +
				KEY_ATTENDANCE_SESSION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
				KEY_ATTENDANCE_SESSION_FACULTY_ID + " INTEGER, " + 
				KEY_ATTENDANCE_SESSION_DEPARTMENT + " TEXT, " +
				KEY_ATTENDANCE_SESSION_CLASS + " TEXT, " +
				KEY_ATTENDANCE_SESSION_DATE + " DATE," +
				KEY_ATTENDANCE_SESSION_SUBJECT + " TEXT" + ")";
		Log.d("queryAttendanceSession",queryAttendanceSession );


		String queryAttendance="CREATE TABLE "+ ATTENDANCE_TABLE +" (" +
				KEY_SESSION_ID + " INTEGER, " +
				KEY_ATTENDANCE_STUDENT_ID + " INTEGER, " +
				KEY_ATTENDANCE_STATUS + " TEXT " + ")";
		Log.d("queryAttendance",queryAttendance );


		try
		{
			db.execSQL(queryFaculty);
			db.execSQL(queryStudent);
			db.execSQL(queryAttendanceSession);
			db.execSQL(queryAttendance);
		}
		catch (Exception e) {
			e.printStackTrace();
			Log.e("Exception", e.getMessage());
		}

	} 


	@Override
	public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
		String queryFaculty="CREATE TABLE "+ ATTENDER_INFO_TABLE +" (" +
				KEY_ATTENDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
				KEY_ATTENDER_FIRSTNAME + " TEXT, " +
				KEY_ATTENDER_LASTNAME + " TEXT, " +
				KEY_ATTENDER_MO_NO + " TEXT, " +
				KEY_ATTENDER_ADDRESS + " TEXT," +
				KEY_ATTENDER_USERNAME + " TEXT," +
				KEY_ATTENDER_PASSWORD + " TEXT " + ")";
		Log.d("queryFaculty",queryFaculty);


		String queryStudent="CREATE TABLE "+ EMPLOYEE_INFO_TABLE +" (" +
				KEY_EMPLOYEE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
				KEY_EMPLOYEE_FIRSTNAME + " TEXT, " +
				KEY_EMPLOYEE_LASTNAME + " TEXT, " +
				KEY_EMPLOYEE_MO_NO + " TEXT, " +
				KEY_EMPLOYEE_ADDRESS + " TEXT," +
				KEY_EMPLOYEE_DEPARTMENT + " TEXT," +
				KEY_EMPLOYEE_CLASS + " TEXT " + ")";
		Log.d("queryStudent",queryStudent );


		String queryAttendanceSession="CREATE TABLE "+ ATTENDANCE_SESSION_TABLE +" (" +
				KEY_ATTENDANCE_SESSION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
				KEY_ATTENDANCE_SESSION_FACULTY_ID + " INTEGER, " + 
				KEY_ATTENDANCE_SESSION_DEPARTMENT + " TEXT, " +
				KEY_ATTENDANCE_SESSION_CLASS + " TEXT, " +
				KEY_ATTENDANCE_SESSION_DATE + " TEXT," +
				KEY_ATTENDANCE_SESSION_SUBJECT + " TEXT" +")";
		Log.d("queryAttendanceSession",queryAttendanceSession );


		String queryAttendance="CREATE TABLE "+ ATTENDANCE_TABLE +" (" +
				KEY_SESSION_ID + " INTEGER, " +
				KEY_ATTENDANCE_STUDENT_ID + " INTEGER, " +
				KEY_ATTENDANCE_STATUS + " TEXT " + ")";
		Log.d("queryAttendance",queryAttendance );

		try
		{
			db.execSQL(queryFaculty);
			db.execSQL(queryStudent);
			db.execSQL(queryAttendanceSession);
			db.execSQL(queryAttendance);
		}
		catch (Exception e) {
			e.printStackTrace();
			Log.e("Exception", e.getMessage());
		}		
	}

	//facult crud
	public void addFaculty(AttenderBean attenderBean) {
		SQLiteDatabase db = this.getWritableDatabase();

		String query = "INSERT INTO attender_table (attender_firstname,attender_Lastname,attender_mobilenumber,attender_address,attender_username,attender_password) values ('"+
				attenderBean.getAttender_firstname()+"', '"+
				attenderBean.getAttender_lastname()+"', '"+
				attenderBean.getAttender_mobilenumber()+"', '"+
				attenderBean.getAttender_address()+"', '"+
				attenderBean.getAttender_username()+"', '"+
				attenderBean.getAttender_password()+"')";
		Log.d("query", query);
		db.execSQL(query);
		db.close();
	}

	public AttenderBean validateFaculty(String userName, String password)
	{
		SQLiteDatabase db = this.getWritableDatabase();
		
		String query = "SELECT * FROM attender_table where attender_username='"+userName+"' and attender_password='"+password+"'";
		Cursor cursor = db.rawQuery(query, null);

		if(cursor.moveToFirst()) 
		{
			
				AttenderBean attenderBean = new AttenderBean();
				attenderBean.setAttender_id(Integer.parseInt(cursor.getString(0)));
				attenderBean.setAttender_firstname(cursor.getString(1));
				attenderBean.setAttender_lastname(cursor.getString(2));
				attenderBean.setAttender_mobilenumber(cursor.getString(3));
				attenderBean.setAttender_address(cursor.getString(4));
				attenderBean.setAttender_username(cursor.getString(5));
				attenderBean.setAttender_password(cursor.getString(6));
				return attenderBean;
		}
		return null;
	}

	public ArrayList<AttenderBean> getAllFaculty()
	{
		Log.d("in get all","in get all" );
		ArrayList<AttenderBean> list = new ArrayList<AttenderBean>();

		SQLiteDatabase db = this.getWritableDatabase();
		String query = "SELECT * FROM attender_table";
		Cursor cursor = db.rawQuery(query, null);

		if(cursor.moveToFirst()) 
		{
			do{
				AttenderBean attenderBean = new AttenderBean();
				attenderBean.setAttender_id(Integer.parseInt(cursor.getString(0)));
				attenderBean.setAttender_firstname(cursor.getString(1));
				attenderBean.setAttender_lastname(cursor.getString(2));
				attenderBean.setAttender_mobilenumber(cursor.getString(3));
				attenderBean.setAttender_address(cursor.getString(4));
				attenderBean.setAttender_username(cursor.getString(5));
				attenderBean.setAttender_password(cursor.getString(6));
				list.add(attenderBean);

			}while(cursor.moveToNext());
		}
		return list;
	}

	public void deleteFaculty(int attenderId) {
		SQLiteDatabase db = this.getWritableDatabase();

		String query = "DELETE FROM attender_table WHERE attender_id="+attenderId ;

		Log.d("query", query);
		db.execSQL(query);
		db.close();
	}

	//student crud
	public void addStudent(EmployeeBean employeeBean) {
		SQLiteDatabase db = this.getWritableDatabase();

		String query = "INSERT INTO employee_table (employee_firstname,employee_lastname,employee_mobilenumber,employee_address,employee_department,employee_class) values ('"+ 
				employeeBean.getEmployee_firstname()+"', '"+
				employeeBean.getEmployee_lastname()+"','"+
				employeeBean.getEmployee_mobilenumber()+"', '"+
				employeeBean.getEmployee_address()+"', '"+
				employeeBean.getEmployee_department()+"', '"+
				employeeBean.getEmployee_class()+"')";
		Log.d("query", query);
		db.execSQL(query);
		db.close();
	}

	public ArrayList<EmployeeBean> getAllStudent()
	{
		ArrayList<EmployeeBean> list = new ArrayList<EmployeeBean>();

		SQLiteDatabase db = this.getWritableDatabase();
		String query = "SELECT * FROM employee_table";
		Cursor cursor = db.rawQuery(query, null);

		if(cursor.moveToFirst()) 
		{
			do{
				EmployeeBean employeeBean = new EmployeeBean();
				employeeBean.setEmployee_id(Integer.parseInt(cursor.getString(0)));
				employeeBean.setEmployee_firstname(cursor.getString(1));
				employeeBean.setEmployee_lastname(cursor.getString(2));
				employeeBean.setEmployee_mobilenumber(cursor.getString(3));
				employeeBean.setEmployee_address(cursor.getString(4));
				employeeBean.setEmployee_department(cursor.getString(5));
				employeeBean.setEmployee_class(cursor.getString(6));
				list.add(employeeBean);
			}while(cursor.moveToNext());
		}
		return list;
	}

	public ArrayList<EmployeeBean> getAllStudentByBranchYear(String branch, String year)
	{
		ArrayList<EmployeeBean> list = new ArrayList<EmployeeBean>();

		SQLiteDatabase db = this.getWritableDatabase();
		String query = "SELECT * FROM employee_table where employee_department='"+branch+"' and employee_class='"+year+"'";
		Cursor cursor = db.rawQuery(query, null);

		if(cursor.moveToFirst()) 
		{
			do{
				EmployeeBean employeeBean = new EmployeeBean();
				employeeBean.setEmployee_id(Integer.parseInt(cursor.getString(0)));
				employeeBean.setEmployee_firstname(cursor.getString(1));
				employeeBean.setEmployee_lastname(cursor.getString(2));
				employeeBean.setEmployee_mobilenumber(cursor.getString(3));
				employeeBean.setEmployee_address(cursor.getString(4));
				employeeBean.setEmployee_department(cursor.getString(5));
				employeeBean.setEmployee_class(cursor.getString(6));
				list.add(employeeBean);
			}while(cursor.moveToNext());
		}
		return list;
	}

	public EmployeeBean getEmplyoeeId(int employeeId)
	{
		EmployeeBean employeeBean = new EmployeeBean();
		SQLiteDatabase db = this.getWritableDatabase();
		String query = "SELECT * FROM employee_table where employee_id="+employeeId;
		Cursor cursor = db.rawQuery(query, null);

		if(cursor.moveToFirst()) 
		{
			do{

				employeeBean.setEmployee_id(Integer.parseInt(cursor.getString(0)));
				employeeBean.setEmployee_firstname(cursor.getString(1));
				employeeBean.setEmployee_lastname(cursor.getString(2));
				employeeBean.setEmployee_mobilenumber(cursor.getString(3));
				employeeBean.setEmployee_address(cursor.getString(4));
				employeeBean.setEmployee_department(cursor.getString(5));
				employeeBean.setEmployee_class(cursor.getString(6));
				
			}while(cursor.moveToNext());
		}
		return employeeBean;
	}

	public void deleteEmployee(int employeeId) {
		SQLiteDatabase db = this.getWritableDatabase();

		String query = "DELETE FROM employee_table WHERE employee_id="+employeeId ;

		Log.d("query", query);
		db.execSQL(query);
		db.close();
	}

	//attendance session Table crud
	public int addAttendanceSession(AttendanceSessionBean attendanceSessionBean) {
		SQLiteDatabase db = this.getWritableDatabase();

		String query = "INSERT INTO attendance_session_table (attendance_session_faculty_id,attendance_session_department,attendance_session_class,attendance_session_date,attendance_session_subject) values ('"+ 
				attendanceSessionBean.getAttendance_session_faculty_id()+"', '"+
				attendanceSessionBean.getAttendance_session_department()+"','"+
				attendanceSessionBean.getAttendance_session_class()+"', '"+
				attendanceSessionBean.getAttendance_session_date()+"', '"+
				attendanceSessionBean.getAttendance_session_subject()+"')";
		Log.d("query", query);
		db.execSQL(query);

		String query1= "select max(attendance_session_id) from attendance_session_table";
		Cursor cursor = db.rawQuery(query1, null);
		
		if(cursor.moveToFirst())
		{
			int sessionId = Integer.parseInt(cursor.getString(0));
			
			return sessionId;
		}
			
		
		db.close();
		return 0;
	}

	public ArrayList<AttendanceSessionBean> getAllAttendanceSession()
	{
		ArrayList<AttendanceSessionBean> list = new ArrayList<AttendanceSessionBean>();

		SQLiteDatabase db = this.getWritableDatabase();
		String query = "SELECT * FROM attendance_session_table";
		Cursor cursor = db.rawQuery(query, null);

		if(cursor.moveToFirst()) 
		{
			do{
				AttendanceSessionBean attendanceSessionBean = new AttendanceSessionBean();
				attendanceSessionBean.setAttendance_session_id(Integer.parseInt(cursor.getString(0)));
				attendanceSessionBean.setAttendance_session_faculty_id(Integer.parseInt(cursor.getString(1)));
				attendanceSessionBean.setAttendance_session_department(cursor.getString(2));
				attendanceSessionBean.setAttendance_session_class(cursor.getString(3));
				attendanceSessionBean.setAttendance_session_date(cursor.getString(4));
				attendanceSessionBean.setAttendance_session_subject(cursor.getString(5));
				list.add(attendanceSessionBean);
			}while(cursor.moveToNext());
		}
		return list;
	}

	public void deleteAttendanceSession(int attendanceSessionId) {
		SQLiteDatabase db = this.getWritableDatabase();

		String query = "DELETE FROM attendance_session_table WHERE attendance_session_id="+attendanceSessionId ;

		Log.d("query", query);
		db.execSQL(query);
		db.close();
	}
	//attendance crud
	public void addNewAttendance(AttendanceBean attendanceBean) {
		SQLiteDatabase db = this.getWritableDatabase();

		String query = "INSERT INTO attendance_table values ("+ 
				attendanceBean.getAttendance_session_id()+", "+
				attendanceBean.getAttendance_student_id()+", '"+
				attendanceBean.getAttendance_status()+"')";
		Log.d("query", query);
		db.execSQL(query);
		db.close();
	}
	
	
	public ArrayList<AttendanceBean> getAttendanceBySessionID(AttendanceSessionBean attendanceSessionBean)
	{
		int attendanceSessionId=0;
		ArrayList<AttendanceBean> list = new ArrayList<AttendanceBean>();

		SQLiteDatabase db = this.getWritableDatabase();
		String query = "SELECT * FROM attendance_session_table where attendance_session_faculty_id="+attendanceSessionBean.getAttendance_session_faculty_id()+""
				+" AND attendance_session_department='"+attendanceSessionBean.getAttendance_session_department()+"' AND attendance_session_class='"+attendanceSessionBean.getAttendance_session_class()+"'" +
						" AND attendance_session_date='"+attendanceSessionBean.getAttendance_session_date()+"' AND attendance_session_subject='"+attendanceSessionBean.getAttendance_session_subject()+"'";
		Cursor cursor = db.rawQuery(query, null);

		if(cursor.moveToFirst()) 
		{
			do{
				attendanceSessionId=(Integer.parseInt(cursor.getString(0)));
			}while(cursor.moveToNext());
		}
		
		String query1="SELECT * FROM attendance_table where attendance_session_id=" + attendanceSessionId+" order by attendance_student_id";
		Cursor cursor1 = db.rawQuery(query1, null);
		if(cursor1.moveToFirst()) 
		{
			do{
				AttendanceBean attendanceBean = new AttendanceBean();
				attendanceBean.setAttendance_session_id(Integer.parseInt(cursor1.getString(0)));
				attendanceBean.setAttendance_student_id(Integer.parseInt(cursor1.getString(1)));
				attendanceBean.setAttendance_status(cursor1.getString(2));
				list.add(attendanceBean);

			}while(cursor1.moveToNext());
		}
		return list;
	}
	
	public ArrayList<AttendanceBean> getTotalAttendanceBySessionID(AttendanceSessionBean attendanceSessionBean)
	{
		int attendanceSessionId=0;
		ArrayList<AttendanceBean> list = new ArrayList<AttendanceBean>();

		SQLiteDatabase db = this.getWritableDatabase();
		String query = "SELECT * FROM attendance_session_table where attendance_session_faculty_id="+attendanceSessionBean.getAttendance_session_faculty_id()+""
				+" AND attendance_session_department='"+attendanceSessionBean.getAttendance_session_department()+"' AND attendance_session_class='"+attendanceSessionBean.getAttendance_session_class()+"'" +
						" AND attendance_session_subject='"+attendanceSessionBean.getAttendance_session_subject()+"'";
		Cursor cursor = db.rawQuery(query, null);

		if(cursor.moveToFirst()) 
		{
			do{
				attendanceSessionId=(Integer.parseInt(cursor.getString(0)));
				
				String query1="SELECT * FROM attendance_table where attendance_session_id=" + attendanceSessionId+" order by attendance_student_id";
				Cursor cursor1 = db.rawQuery(query1, null);
				if(cursor1.moveToFirst()) 
				{
					do{
						AttendanceBean attendanceBean = new AttendanceBean();
						attendanceBean.setAttendance_session_id(Integer.parseInt(cursor1.getString(0)));
						attendanceBean.setAttendance_student_id(Integer.parseInt(cursor1.getString(1)));
						attendanceBean.setAttendance_status(cursor1.getString(2));
						list.add(attendanceBean);

					}while(cursor1.moveToNext());
				}
				
				AttendanceBean attendanceBean = new AttendanceBean();
				attendanceBean.setAttendance_session_id(0);
				attendanceBean.setAttendance_status("Date : " + cursor.getString(4));
				list.add(attendanceBean);
				
			}while(cursor.moveToNext());
		}
		
		
		return list;
	}
	
	public ArrayList<AttendanceBean> getAllAttendanceByStudent()
	{
		ArrayList<AttendanceBean> list = new ArrayList<AttendanceBean>();

		SQLiteDatabase db = this.getWritableDatabase();
		String query = "SELECT attendance_student_id,count(*) FROM attendance_table where attendance_status='P' group by attendance_student_id";
		
		Log.d("query", query);
		
		Cursor cursor = db.rawQuery(query, null);
		
		

		if(cursor.moveToFirst()) 
		{
			do{
				Log.d("studentId","studentId:"+cursor.getString(0)+", Count:"+cursor.getString(1));
				AttendanceBean attendanceBean = new AttendanceBean();
				attendanceBean.setAttendance_student_id(Integer.parseInt(cursor.getString(0)));
				attendanceBean.setAttendance_session_id(Integer.parseInt(cursor.getString(1)));
				list.add(attendanceBean);

			}while(cursor.moveToNext());
		}
		return list;
	}
	/*public ArrayList<AttendanceBean> getAllAttendanceBySessionID(int sessionId)
	{
		ArrayList<AttendanceBean> list = new ArrayList<AttendanceBean>();

		SQLiteDatabase db = this.getWritableDatabase();
		String query = "SELECT * FROM attendance_table where attendance_session_id=" + sessionId;
		Cursor cursor = db.rawQuery(query, null);

		if(!cursor.moveToFirst()) 
		{
			do{
				AttendanceBean attendanceBean = new AttendanceBean();
				attendanceBean.setAttendance_session_id(Integer.parseInt(cursor.getString(0)));
				attendanceBean.setAttendance_student_id(Integer.parseInt(cursor.getString(1)));
				attendanceBean.setAttendance_status(cursor.getString(2));
				list.add(attendanceBean);

			}while(cursor.moveToNext());
		}
		return list;
	}*/
	
	


	// Creating Tables
	/*@Override
	public void onCreate(SQLiteDatabase db) {
		String CREATE_User_Info_TABLE = "CREATE TABLE " + TABLE_INFO_USER + "("
				+ KEY_ID + " INTEGER PRIMARY KEY, " + KEY_FIRSTNAME + " TEXT, "+ KEY_LASTNAME + " TEXT, " +KEY_MO_NO +" TEXT, "
				+KEY_EMAIL +" TEXT, " +KEY_USERNAME +" TEXT, " + KEY_PASSWORD +" TEXT " + ")";

		Log.d("rupali",CREATE_User_Info_TABLE );
		db.execSQL(CREATE_User_Info_TABLE);
	}

	// Upgrading database
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// Drop older table if existed
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_INFO_USER);

		// Create tables again
		onCreate(db);
	}

	 *//**
	 * All CRUD(Create, Read, Update, Delete) Operations
	 *//*



	void addUserInfo(UserInfo userinfo) {
		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();
		values.put(KEY_FIRSTNAME, userinfo.getUser_Firstname()); //  Name
		values.put(KEY_LASTNAME, userinfo.getUser_Lastname()); //  Name
		values.put(KEY_MO_NO, userinfo.getUser_MobileNo()); // Contact Phone
		values.put(KEY_EMAIL, userinfo.getUser_EmailId());
		values.put(KEY_USERNAME, userinfo.getUser_Username());
		values.put(KEY_PASSWORD, userinfo.getUser_Password());

		// Inserting Row
		db.insert(TABLE_INFO_USER, null, values);
		//2nd argument is String containing nullColumnHack
		db.close(); // Closing database connection
	}


	// Getting single contact
	UserInfo getUserInfo(int id) {
		SQLiteDatabase db = this.getReadableDatabase();

		Cursor cursor = db.query(TABLE_INFO_USER, new String[] { KEY_ID,
				KEY_FIRSTNAME, KEY_LASTNAME,KEY_MO_NO,  KEY_EMAIL, KEY_USERNAME, KEY_PASSWORD }, KEY_ID + "=?",
				new String[] { String.valueOf(id) }, null, null, null, null);
		if (cursor != null)
			cursor.moveToFirst();

		UserInfo userinfo = new UserInfo(Integer.parseInt(cursor.getString(0)),
				cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4),cursor.getString(5),cursor.getString(6));
		// return contact
				return userinfo;
	}

	public UserInfo validateUser(String username, String password)
	{
		SQLiteDatabase db = this.getReadableDatabase();
		String query = "Select * from User_Info_Table WHERE User_Username='"+ username +"' AND User_Password='"+password+"'";
		Log.d("Rupali", "Login QUERY:" + query);

		Cursor cursor = db.rawQuery(query, null);


		if(!cursor.moveToFirst()) 
		{
			Log.d("Rupali", "cursor is null.. returing NULL");
			return null;
		}
		Log.d("Rupali", "cursor is NOT null.. we got user data...");


		UserInfo userinfo = new UserInfo(Integer.parseInt(cursor.getString(0)),
				cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4),cursor.getString(5),cursor.getString(6));

		return userinfo;
	}

	// Updating single contact
	public int updateUserPassword(UserInfo userinfo) {
		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();
		values.put(KEY_PASSWORD, userinfo.getUser_Password());


		// updating row
		return db.update(TABLE_INFO_USER, values, KEY_ID + " = ?",
				new String[] { String.valueOf(userinfo.getUser_id()) });
	}

	public int updateUserContact(UserInfo userinfo) {
		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();
		values.put(KEY_MO_NO, userinfo.getUser_MobileNo());
		values.put(KEY_EMAIL, userinfo.getUser_EmailId());


		// updating row
		return db.update(TABLE_INFO_USER, values, KEY_ID + " = ?",
				new String[] { String.valueOf(userinfo.getUser_id()) });
	}


	//veiw details

	public UserInfo viewUserInfo(String id) {
		SQLiteDatabase db = this.getReadableDatabase();

		String query = "Select * from User_Info_Table WHERE id='"+id+"'";
		Cursor cursor = db.rawQuery(query, null);
		if(!cursor.moveToFirst()) 
		{
			Log.d("Rupali", "cursor is null.. returing NULL");
			return null;
		}
		Log.d("Rupali", "cursor is NOT null.. we got user data...");

		UserInfo userinfo = new UserInfo(Integer.parseInt(cursor.getString(0)),
				cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4),cursor.getString(5),cursor.getString(6));
		// return contact
		return userinfo;
	}



	 // Getting All users
    public List<UserInfo> getAllUserInfo() {
        List<UserInfo> userinfolist = new ArrayList<UserInfo>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_INFO_USER;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {

                UserInfo userinfo=new UserInfo();

                userinfo.setUser_id(Integer.parseInt(cursor.getString(0)));
                userinfo.setUser_Lastname(cursor.getString(2));
                userinfo.setUser_Username(cursor.getString(5));
                userinfo.setUser_Firstname(cursor.getString(1));



                // Adding contact to list
                userinfolist.add(userinfo);
            } while (cursor.moveToNext());
        }

        // return contact list
        return userinfolist;
    }

    // Deleting single contact
    public void deleteUser(UserInfo userinfo) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_INFO_USER, KEY_ID + " = ?",
                new String[] { String.valueOf(userinfo.getUser_id()) });
        db.close();
    }
	  */
}