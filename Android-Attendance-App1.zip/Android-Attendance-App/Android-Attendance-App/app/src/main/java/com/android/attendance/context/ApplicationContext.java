package com.android.attendance.context;

import java.util.ArrayList;

import android.app.Application;

import com.android.attendance.bean.AttendanceBean;
import com.android.attendance.bean.AttendanceSessionBean;
import com.android.attendance.bean.AttenderBean;
import com.android.attendance.bean.EmployeeBean;

public class ApplicationContext extends Application {
	private AttenderBean attenderBean;
	private AttendanceSessionBean attendanceSessionBean;
	private ArrayList<EmployeeBean> employeeBeanList;
	private ArrayList<AttendanceBean> attendanceBeanList;
	
	public AttenderBean getAttenderBean() {
		return attenderBean;
	}
	public void setAttenderBean(AttenderBean attenderBean) {
		this.attenderBean = attenderBean;
	}
	public AttendanceSessionBean getAttendanceSessionBean() {
		return attendanceSessionBean;
	}
	public void setAttendanceSessionBean(AttendanceSessionBean attendanceSessionBean) {
		this.attendanceSessionBean = attendanceSessionBean;
	}
	public ArrayList<EmployeeBean> getEmployeeBeanList() {
		return employeeBeanList;
	}
	public void setEmployeeBeanList(ArrayList<EmployeeBean> employeeBeanList) {
		this.employeeBeanList = employeeBeanList;
	}
	public ArrayList<AttendanceBean> getAttendanceBeanList() {
		return attendanceBeanList;
	}
	public void setAttendanceBeanList(ArrayList<AttendanceBean> attendanceBeanList) {
		this.attendanceBeanList = attendanceBeanList;
	}
	
	

}
