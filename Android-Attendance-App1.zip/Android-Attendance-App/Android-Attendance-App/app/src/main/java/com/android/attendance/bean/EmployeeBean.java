package com.android.attendance.bean;

public class EmployeeBean {
	
	private int employee_id;
	private String employee_firstname;
	private String employee_lastname;
	private String employee_mobilenumber;
	private String employee_address;
	private String employee_department;
	private String employee_class;

	public int getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}

	public String getEmployee_firstname() {
		return employee_firstname;
	}

	public void setEmployee_firstname(String employee_firstname) {
		this.employee_firstname = employee_firstname;
	}

	public String getEmployee_lastname() {
		return employee_lastname;
	}

	public void setEmployee_lastname(String employee_lastname) {
		this.employee_lastname = employee_lastname;
	}

	public String getEmployee_mobilenumber() {
		return employee_mobilenumber;
	}

	public void setEmployee_mobilenumber(String employee_mobilenumber) {
		this.employee_mobilenumber = employee_mobilenumber;
	}

	public String getEmployee_address() {
		return employee_address;
	}

	public void setEmployee_address(String employee_address) {
		this.employee_address = employee_address;
	}

	public String getEmployee_department() {
		return employee_department;
	}

	public void setEmployee_department(String employee_department) {
		this.employee_department = employee_department;
	}

	public String getEmployee_class() {
		return employee_class;
	}

	public void setEmployee_class(String employee_class) {
		this.employee_class = employee_class;
	}
}
